<?php 
session_start();
include("dbconfig.php");

if (isset($_POST['save1'])) { // if save button on the form is clicked
    // name of the uploaded file
  
    $filename = $_FILES['myfile']['name'];
    echo "$myfile";
    // destination of the file on the server
    $destination = "uploads/".$_SESSION['subject_id']."/".$filename;

      // fetching from the exp table
    $assign_name = $_POST['assign_name'];
    $sql = "select * from assign where assign_name = '".$assign_name."' and subject_id = '".$_SESSION['subject_id']."'";
    $query = mysqli_query($conn,$sql);
    $row = mysqli_fetch_row($query);
   

   
    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
        echo "You file extension must be .zip, .pdf or .docx";
    } elseif ($_FILES['myfile']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        
        if (move_uploaded_file($file, $destination)) {
            //echo "<h1><script>alert('File uploaded successfully')</script></h1>";
            $sql = "INSERT INTO assign_notes(assign_id,subject_id,student_id,filename,size,assign_name,marks) VALUES('".$row[0]."', '".$_SESSION['subject_id']."', '".$_SESSION['student_id']."', '$file', '$size', '".$assign_name."',0)";
            $query = mysqli_query($conn, $sql);
            $row = mysqli_num_rows($query);
            echo "<script>alert('Success')</script>";
            if ($row>=1) {
                echo "<h1><script>alert('File uploaded successfully')</script></h1>";
            }
        } 
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
   
   <button onclick="window.location.href = 'student_profile.php';">Go to Homepage</button>
   <button onclick="window.location.href = 'upload.php';">Upload another file</button>

</body>
</html>