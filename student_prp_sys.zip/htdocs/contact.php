<?php
//$conn= mysqli_connect('sql211.epizy.com','epiz_24488534','kithsirhs');


include("dbconfig.php");
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$phnum=$_POST['phnum'];
$subject=$_POST['subject'];
$sql="INSERT INTO contact VALUES('$fname','$lname','$phnum','$subject')";
if (mysqli_query($conn, $sql)) 
    echo "New record created successfully";
else
echo "error";
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="navbar.css">
    <style>
        * {box-sizing: border-box;}
    body{background-color:#f5f5f5;
        }
    h2{
        text-align:center;
    }
    .container{
    background-color:#ffff;
    width:90%;
    margin-left:5%;
    padding-top:3%;
    padding-bottom:3%;
}
input[type=text], select, textarea {
  width: 80%;
  margin-left:10%;
  padding: 12px;
  border: 1px solid #2ebfac;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
    margin-left:45%;
  background-color: #2ebfac;
  color: white;
  padding-left:3%;
  padding-right:3%;
  padding-top:1%;
  padding-bottom:1%;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: white;
  border: solid 3px #2ebfac;
  color:#2ebfac;
  text-width: strong;
}
.lab{
    margin-left:10%;
}

.active {
    color:#888888;
}
    </style>
<body>
<header>
  <ul>
  <li><a href="index.html">Home</a></li>
    <li style="float:right" ><a href="aboutus.html">About us</a></li>
    <li style="float:right" ><a class="active" href="contact.php">Contact us</a></li>
      <li><a href="recent_activity.html">Recent activities</a></li>
      <li><a href="upcoming.html">Upcoming events</a></li>
  </ul>
</header> 
<br><br><br>
<div class="container" style="text-align:center;"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1363.584488107743!2d72.84133401298932!3d19.04473150886879!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c92fb093d785%3A0x38854a716f0ca945!2sXavier%20Institute%20of%20Engineering!5e0!3m2!1sen!2sin!4v1572707495855!5m2!1sen!2sin" width="800" height="600" frameborder="0" style="border:0;" allowfullscreen=""></iframe><br><br>
<h2><b>ADDRESS:</b> Opposite S.L.Raheja Hospital, Mahim Causeway, Mahim (West), Mumbai-400016</h2><br>
<h2><b>Contact No:</b> 022 - 24451961 / 24460359 / 24454559 / 24455937/ 24469670</h2>
</div>
<br><br><br>
<div class="container">
<h1 style="text-align:center;">CONTACT US</h1>
<form method="POST" autocomplete="off">
    <label class="lab" for="fname">FIRST NAME</label><br>
    <input type="text" id="fname" name="fname" placeholder="Your name..."><br>

    <label class="lab" for="lname">LAST NAME</label><br>
    <input type="text" id="lname" name="lname" placeholder="Your last name..."><br>

    <label class="lab" for="phnum">PHONE NUMBER</label><br>
    <input type="text" id="phnum" name="phnum" placeholder="Your phone number..."><br>
    
    <label class="lab" for="subject">SUBJECT</label><br>
    <textarea id="subject" name="subject" placeholder="Write complaints/suggestions" style="height:200px"></textarea><br>

    <input type="submit" name="submit" value="SUBMIT">
  </form>
</div>
</body>
</html>