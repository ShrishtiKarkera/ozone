<?php

$conn = mysqli_connect("sql211.epizy.com","epiz_24488534","tNmxBE5wpr9CW","epiz_24488534_sprocs");

 if(! $conn ) {
            die('Could not connect: ' . mysql_error());
         }
        // echo "Connected Successfully";
?>