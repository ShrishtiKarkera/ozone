
<!DOCTYPE html>
 
<html>
<head>

	<title>doubtbox</title>
     <style>
body {background-color:#f5f5f5;
        }
         

        .container1{
            padding:3% 5%;
	border: solid 1px #888888;
	width:30%;
	margin-left: 30%;
	margin-top: 5%;
    background-color:white;
    color:#888888;
}
.container2{
    //padding:3% 5%;
	border: solid 1px #888888;
	width:40%;
	margin-left: 30%;
    background-color:white;
}

input[type=textarea] {
  width: 70%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border:solid #888888;
  border-width: 0px 1px 0px 0px;
  border-radius: 4px;
  background-color: white;
  resize: none;
  color:#888888;
}
input[type=submit]{
  background-color:#2ebfac;
  border: solid 1px #888888;
  color:white;
  padding:3% 5%;
  text-decoration: none;
  margin-left: 7%;
  margin-top:5%;
  border-radius:6px;
  cursor: pointer;
}


</style>

</head>
 
<body>

	<div class="container1"> 

		<?php
	
    session_start();
//$conn = mysqli_connect("sql211.epizy.com","epiz_24488534","tNmxBE5wpr9CW","epiz_24488534_sprocs");
// $conn=mysqli_connect("localhost","root","","chat");
  include("dbconfig.php");
 if(! $conn ) {
            die('Could not connect: ' . mysql_error());
         }
        echo "Connected Successfully";

         ?>
    
<table>
    <tr>
      <td>date</td>
      <td>time</td>
      <td>name</td>
      <td>message</td>
    </tr>

    <tr>
      <?php
 $sql="SELECT * FROM demo";
     $result=mysqli_query($conn,$sql);
                   
                    //echo"inside loop";
                    
                   while($row=mysqli_fetch_array($result))
                     {  
                ?>
                <tr>
                  <td><?php echo $row['date']; ?></td> 
                  <td><?php echo $row['time']; ?></td> 
                  <td><?php echo $row['name'].":"; ?></td>
                  <td><?php echo $row['message']; ?></td>
                 </tr> 
                <?php

                }
                
                 ?>

    </tr>

  </table>

  </div>


  <div class="container2">
  <form action='insert.php' method='post' id='myform' >
 
  <input type='textarea' name='message' placeholder='message' id='message' />
      
  <input type="submit" value="send">
  
  </form>
</div>
</body>
</html>

		