<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="navbar.css">
<style>
* {
  box-sizing: border-box;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 50%;
  padding: 0 20px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 800px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  width:100%;
  padding:7% 0%;
  text-align: center;
  background-color:#2ebfac;
  border: solid 1px #2ebfac;
}

.card2 {background-color: white;
margin-left:5%;
padding: 4% 3%;
border: solid 1px #888888;
border-radius:6px;
width: 90%;
color: #888888;
}
.card:hover {
    text-decoration: none;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
h3{
    color:#888888;
}

.but1{
    margin-left:5%; 
    border-radius:8px;
    background-color:#888888;
    color:white;
    border: solid 1.5px white;
    cursor:pointer;
    padding:3% 7%;
    
}
.but1:hover{
    background-color:white;
    color:#888888;
    border: solid 1.5px #888888;
}
.but2{
    border-radius:6px;
    //border:none;
    border: solid 1.5px #2ebfac;
     background-color:white;
     
}
h4{
    color:#888888;
}
</style>
</head>
<body>
<header>
    <ul>
     <li style=""><a class="icons" href="student_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
      <li style=""><a href="IP_02.html" target="_blank">TIMETABLE</a></li>
      <li style=""><a href="mail.php">SEND MAIL</a></li>
      <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOGOUT</a></li>
      <li style="float:right;"><a href="view_marks.php">VIEW MARKS</a></li>
      <li style="float:right;"><a href="view_notif.php">NOTIFICATIONS</a></li>
      <li style="float:right;"><a href="upload.php">SUBMISSIONS</a></li>
      <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li> 
    </ul>
  </header>
  <br> <br> <br> <br> <br> <br> 
<?php

if (isset($_POST['s_01'])){

$_SESSION["subject_id"] = "s_01";
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <form action="exp_upload.php" method="post" enctype="multipart/form-data">
      	Experiment Name: <select name="exp_name">
   						 <option value="Experiment No.01">Experiment No.01</option>
   						 <option value="Experiment No.02">Experiment No.02</option>
   						 <option value="Experiment No.03">Experiment No.03</option>
  						 <option value="Experiment No.04">Experiment No.04</option>
  						 <option value="Experiment No.05">Experiment No.05</option>
  						 <option value="Experiment No.06">Experiment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>

<div class="column">
    <div class="card">
    <div class="card2">
      <form action="assign_upload.php" method="post" enctype="multipart/form-data">
      	Assignment Name: <select name="assign_name">
   						 <option value="Assignment No. 01">Assignment No.01</option>
   						 <option value="Assignment No. 02">Assignment No.02</option>
   						 <option value="Assignment No. 03">Assignment No.03</option>
  						 <option value="Assignment No. 04">Assignment No.04</option>
  						 <option value="Assignment No. 05">Assignment No.05</option>
  						 <option value="Assignment No. 06">Assignment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save1"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>
        <?
    }
?>

<?php

if (isset($_POST['s_02'])){

$_SESSION["subject_id"] = "s_02";
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <form action="exp_upload.php" method="post" enctype="multipart/form-data">
      	Experiment Name: <select name="exp_name">
   						 <option value="Experiment No.01">Experiment No.01</option>
   						 <option value="Experiment No.02">Experiment No.02</option>
   						 <option value="Experiment No.03">Experiment No.03</option>
  						 <option value="Experiment No.04">Experiment No.04</option>
  						 <option value="Experiment No.05">Experiment No.05</option>
  						 <option value="Experiment No.06">Experiment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>

<div class="column">
    <div class="card">
    <div class="card2">
      <form action="assign_upload.php" method="post" enctype="multipart/form-data">
      	Assignment Name: <select name="assign_name">
   						 <option value="Assignment No. 01">Assignment No.01</option>
   						 <option value="Assignment No. 02">Assignment No.02</option>
   						 <option value="Assignment No. 03">Assignment No.03</option>
  						 <option value="Assignment No. 04">Assignment No.04</option>
  						 <option value="Assignment No. 05">Assignment No.05</option>
  						 <option value="Assignment No. 06">Assignment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save1"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>
        <?
    }
?>

<?php

if (isset($_POST['s_03'])){

$_SESSION["subject_id"] = "s_03";
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <form action="exp_upload.php" method="post" enctype="multipart/form-data">
      	Experiment Name: <select name="exp_name">
   						 <option value="Experiment No.01">Experiment No.01</option>
   						 <option value="Experiment No.02">Experiment No.02</option>
   						 <option value="Experiment No.03">Experiment No.03</option>
  						 <option value="Experiment No.04">Experiment No.04</option>
  						 <option value="Experiment No.05">Experiment No.05</option>
  						 <option value="Experiment No.06">Experiment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>

<div class="column">
    <div class="card">
    <div class="card2">
      <form action="assign_upload.php" method="post" enctype="multipart/form-data">
      	Assignment Name: <select name="assign_name">
   						 <option value="Assignment No. 01">Assignment No.01</option>
   						 <option value="Assignment No. 02">Assignment No.02</option>
   						 <option value="Assignment No. 03">Assignment No.03</option>
  						 <option value="Assignment No. 04">Assignment No.04</option>
  						 <option value="Assignment No. 05">Assignment No.05</option>
  						 <option value="Assignment No. 06">Assignment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save1"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>
        <?
    }
?>

<?php

if (isset($_POST['s_04'])){

$_SESSION["subject_id"] = "s_04";
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <form action="exp_upload.php" method="post" enctype="multipart/form-data">
      	Experiment Name: <select name="exp_name">
   						 <option value="Experiment No.01">Experiment No.01</option>
   						 <option value="Experiment No.02">Experiment No.02</option>
   						 <option value="Experiment No.03">Experiment No.03</option>
  						 <option value="Experiment No.04">Experiment No.04</option>
  						 <option value="Experiment No.05">Experiment No.05</option>
  						 <option value="Experiment No.06">Experiment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>

<div class="column">
    <div class="card">
    <div class="card2">
      <form action="assign_upload.php" method="post" enctype="multipart/form-data">
      	Assignment Name: <select name="assign_name">
   						 <option value="Assignment No. 01">Assignment No.01</option>
   						 <option value="Assignment No. 02">Assignment No.02</option>
   						 <option value="Assignment No. 03">Assignment No.03</option>
  						 <option value="Assignment No. 04">Assignment No.04</option>
  						 <option value="Assignment No. 05">Assignment No.05</option>
  						 <option value="Assignment No. 06">Assignment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save1"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>
        <?
    }
?>

<?php

if (isset($_POST['s_05'])){

$_SESSION["subject_id"] = "s_05";
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <form action="exp_upload.php" method="post" enctype="multipart/form-data">
      	Experiment Name: <select name="exp_name">
   						 <option value="Experiment No.01">Experiment No.01</option>
   						 <option value="Experiment No.02">Experiment No.02</option>
   						 <option value="Experiment No.03">Experiment No.03</option>
  						 <option value="Experiment No.04">Experiment No.04</option>
  						 <option value="Experiment No.05">Experiment No.05</option>
  						 <option value="Experiment No.06">Experiment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>

<div class="column">
    <div class="card">
    <div class="card2">
      <form action="assign_upload.php" method="post" enctype="multipart/form-data">
      	Assignment Name: <select name="assign_name">
   						 <option value="Assignment No. 01">Assignment No.01</option>
   						 <option value="Assignment No. 02">Assignment No.02</option>
   						 <option value="Assignment No. 03">Assignment No.03</option>
  						 <option value="Assignment No. 04">Assignment No.04</option>
  						 <option value="Assignment No. 05">Assignment No.05</option>
  						 <option value="Assignment No. 06">Assignment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save1"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>
        <?
    }
?>
<?php

if (isset($_POST['s_06'])){

$_SESSION["subject_id"] = "s_06";
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <form action="exp_upload.php" method="post" enctype="multipart/form-data">
      	Experiment Name: <select name="exp_name">
   						 <option value="Experiment No.01">Experiment No.01</option>
   						 <option value="Experiment No.02">Experiment No.02</option>
   						 <option value="Experiment No.03">Experiment No.03</option>
  						 <option value="Experiment No.04">Experiment No.04</option>
  						 <option value="Experiment No.05">Experiment No.05</option>
  						 <option value="Experiment No.06">Experiment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>

<div class="column">
    <div class="card">
    <div class="card2">
      <form action="assign_upload.php" method="post" enctype="multipart/form-data">
      	Assignment Name: <select name="assign_name">
   						 <option value="Assignment No. 01">Assignment No.01</option>
   						 <option value="Assignment No. 02">Assignment No.02</option>
   						 <option value="Assignment No. 03">Assignment No.03</option>
  						 <option value="Assignment No. 04">Assignment No.04</option>
  						 <option value="Assignment No. 05">Assignment No.05</option>
  						 <option value="Assignment No. 06">Assignment No.06</option>
                         </select>
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save1"><b>UPLOAD</b></button>
        </form>
    </div>
  </div>
</div>
        <?
    }
?>
</body>
</html>
