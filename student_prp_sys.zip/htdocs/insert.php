<?php

session_start();
//$conn = mysqli_connect("sql211.epizy.com","epiz_24488534","tNmxBE5wpr9CW","epiz_24488534_sprocs");
// $conn=mysqli_connect("localhost","root","","chat");
  include("dbconfig.php");
 if(! $conn ) {
            die('Could not connect: ' . mysql_error());
         }
        //  echo "Connected Successfully"; 
 		//include("dbconfig.php");        
     echo "COnnected successfully";
         $name=$_SESSION['username'];
         $message=$_POST['message'];
         $date=date('Y-m-d');
         $time=date('H:i:s');
         $sql="INSERT INTO demo(date,time,name,message) VALUES('".$date."','".$time."','".$name."','".$message."')";
         if(mysqli_query($conn, $sql)){
		echo 'success';
		header("Location:doubt.php");
	}
?>