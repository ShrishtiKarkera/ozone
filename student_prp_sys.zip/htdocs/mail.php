<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="navbar.css">
    <style>
* {
  box-sizing: border-box;
}




/* Style the counter cards */
.card {
  //box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding-top:3%;
  padding-bottom:3%;
  text-align: center;
  width:60%;
  margin-left:20%;
  background-color: #2ebfac;
  color:white;
  font-size:25px;
  border: solid 4px #888888;
  border-radius: 12px;
}

.card:hover {
border: solid 4px #2ebfac;
  color: #2ebfac;
  background-color: white;
  text-decoration: none;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.but2{
border-radius:6px;
background-color:white;
color:#2ebfac;
border:solid 2px #2ebfac;
padding:2%;
 box-shadow:none;
}
.but2:hover{
    border-radius:6px;
background-color:#2ebfac;
color:white;
border:none;
padding:2%;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

}


.ab{
    width:200px;
}
.container{
    background-color:#ffff;
    width:100%;
    left:0%;
    padding-top:7%;
    padding-bottom:7%;
}
.active {
    color:#888888;
}
</style>
</head>
<body>
<header>
<ul>
      <li style=""><a class="icons" href="student_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
      <li style=""><a href="IP_02.html" target="_blank">TIMETABLE</a></li>
      <li style=""><a class="active" href="mail.php">SEND MAIL</a></li>
      <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOGOUT</a></li>
      <li style="float:right;"><a href="view_marks.php">VIEW MARKS</a></li>
      <li style="float:right;"><a href="view_notif.php">NOTIFICATIONS</a></li>
      <li style="float:right;"><a href="upload.php">SUBMISSIONS</a></li>
      <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
</ul>
</header>

<br> <br> <br> <br> <br> <br> <br> 
<div class="container">
<div class="card">
    <form method="POST" action="?">
    	ENTER SUBJECT :<br> <input type="text" name="subject"><br><br>
    	ENTER MESSAGE :<br> <input type="text" name="message"><br><br>
    	<button type="submit" class="but2" name="submit">SEND</button>
    </form>
    </div>
    </div>
</body>
</html>

<?php
session_start();
if (isset($_POST['submit']))
{
$to = "shrishtikarkera@gmail.com";
// $subject = $_POST['subject'];
// $message = $_POST['message'];
$subject ="Hello";
$message = "hello";
$from = "shrishtikarkera@sprocs.gq";
$headers = $from;
if(mail($to, $subject, $message, $headers)){
	echo "<script> alert('Mail sent successfully');</script>";
}
else{
	echo "<script> alert('Cannot send the mail');</script>";
}}
?>