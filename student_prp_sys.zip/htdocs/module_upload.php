<?php
session_start();
include("dbconfig.php");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="navbar.css">
<style>
* {
  box-sizing: border-box;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 16.6%;
  padding: 0 20px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 800px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  width:100%;
  padding:7% 0%;
  text-align: center;
  background-color:#2ebfac;
  border: solid 1px #2ebfac;
}

.card2 {background-color: white;
margin-left:5%;
padding: 4% 3%;
border: solid 1px #888888;
border-radius:6px;
width: 90%;
color: #888888;
}
.card:hover {
    text-decoration: none;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
h3{
    color:#888888;
}

.but1{
    margin-left:5%; 
    border-radius:8px;
    background-color:#888888;
    color:white;
    border: solid 1.5px white;
    cursor:pointer;
    padding:3% 7%;
    
}
.but1:hover{
    background-color:white;
    color:#888888;
    border: solid 1.5px #888888;
}
.but2{
    border-radius:6px;
    //border:none;
    border: solid 1.5px #2ebfac;
     background-color:white;
     
}
h4{
    color:#888888;
}
/*
.container{
    background-color:#ffff;
    width:100%;
    left:0%;
    padding-top:8%;
    padding-bottom:8%;
}
*/
</style>
</head>
<body>
<header>
    <ul>
     <li style=""><a class="icons" href="student_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
      <li style=""><a href="IP_02.html" target="_blank">TIMETABLE</a></li>
      <li style=""><a href="mail.php">SEND MAIL</a></li>
      <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOGOUT</a></li>
      <li style="float:right;"><a href="view_marks.php">VIEW MARKS</a></li>
      <li style="float:right;"><a href="view_notif.php">NOTIFICATIONS</a></li>
      <li style="float:right;"><a href="upload.php">SUBMISSIONS</a></li>
      <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li> 
    </ul>
  </header>
  <br> <br> <br> <br> <br> <br> 
  

<form method="POST" action="exp_upload.php">

<div class="row">

<?php echo "EXPERIMENTS"?>

<?php

if (isset($_POST['s_01'])){
$sql = "select * from exp where subject_id='s_01'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_01";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["exp_name"];$_SESSION['exp_id'] = $row["exp_id"];$_SESSION['exp_name'] = $row["exp_name"];?></h3></button>
      <form action="exp_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
        <?
    }}}
?>
<?php

if (isset($_POST['s_02'])){
$sql = "select * from exp where subject_id='s_02'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_02";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["exp_name"];$_SESSION['exp_id'] = $row["exp_id"];$_SESSION['exp_name'] = $row["exp_name"];?></h3></button>
      <form action="exp_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center>UPLOAD FILE</center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
        <?
    }}}
?>
<?php

if (isset($_POST['s_03'])){
$sql = "select * from exp where subject_id='s_03'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_03";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["exp_name"];$_SESSION['exp_id'] = $row["exp_id"];$_SESSION['exp_name'] = $row["exp_name"];?></h3></button>
      <form action="exp_upload.php" method="post" enctype="multipart/form-data" >
          <h3><center><b>Upload File</b></center></h3>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
        </div>
    </div>
  </div>
        <?
    }}}   
?>

<?php

if (isset($_POST['s_04'])){
$sql = "select * from exp where subject_id='s_04'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_04";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {$data = $row["exp_name"];
        ?>
        
  <div class="column">
    <div class="card">
    <div class="card2">
      <input type="hidden" value="' . htmlspecialchars($data) . '" />
     <button class="but2" type="button"><h2><?php echo $row["exp_name"];?></h2></button>
      <form action="exp_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
        </div>
    </div>
  </div>
  
        <?
    }}}
?>

<?php

if (isset($_POST['s_05'])){
$sql = "select * from exp where subject_id='s_05'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_05";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["exp_name"];$_SESSION['exp_id'] = $row["exp_id"];$_SESSION['exp_name'] = $row["exp_name"];?></h3></button>
      <form action="exp_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div></div>
  </div>
  
        <?
    }}}
?>
<?php

if (isset($_POST['s_06'])){
$sql = "select * from exp where subject_id='s_06'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_06";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
        
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["exp_name"];$_SESSION['exp_id'] = $row["exp_id"];$_SESSION['exp_name'] = $row["exp_name"];?></h3></button>
      <form action="exp_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div></div>
  </div>
  
        <?
    }}}
?>
</div>
</form>

<br>
<br>
<br>
<br>
<br>
<br>

<!-- this is where the assignments start from -->

<form method="POST" action="assign_upload.php">
<div class="row">

<?php echo "ASSIGNMENTS"?>

<?php

if (isset($_POST['s_01'])){
$sql = "select * from assign where subject_id='s_01'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_01";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
        
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["assign_name"];$_SESSION['assign_id'] = $row["assign_id"];$_SESSION['assign_name'] = $row["assign_name"];?></h3></button>
      <form action="assign_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
  
  
        <?
    }}}
?>
<?php

if (isset($_POST['s_02'])){
$sql = "select * from assign where subject_id='s_02'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_02";

if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["assign_name"];$_SESSION['assign_id'] = $row["assign_id"];$_SESSION['assign_name'] = $row["assign_name"];?></h3></button>
      <form action="assign_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
  
        <?
    }}}
?>
<?php

if (isset($_POST['s_03'])){
$sql = "select * from assign where subject_id='s_03'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_03";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
        
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["assign_name"];$_SESSION['assign_id'] = $row["assign_id"];$_SESSION['assign_name'] = $row["assign_name"];?></h3></button>
      <form action="assign_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
 
   
        <?
    }}}
?>

<?php

if (isset($_POST['s_04'])){
$sql = "select * from assign where subject_id='s_04'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_04";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
        
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["assign_name"];$_SESSION['assign_id'] = $row["assign_id"];$_SESSION['assign_name'] = $row["assign_name"];?></h3></button>
      <form action="assign_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
 
   
        <?
    }}}
?>
<?php

if (isset($_POST['s_05'])){
$sql = "select * from assign where subject_id='s_05'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_05";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["assign_name"];$_SESSION['assign_id'] = $row["assign_id"];$_SESSION['assign_name'] = $row["assign_name"];?></h3></button>
      <form action="assign_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
  
        <?
    }}}
?>
<?php

if (isset($_POST['s_06'])){
$sql = "select * from assign where subject_id='s_06'";
$query = mysqli_query($conn,$sql);
$_SESSION["subject_id"] = "s_06";
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        ?>
       
  <div class="column">
    <div class="card">
    <div class="card2">
      <button class="but2" type="button"><h3><?php echo $row["assign_name"];$_SESSION['assign_id'] = $row["assign_id"];$_SESSION['assign_name'] = $row["assign_name"];?></h3></button>
      <form action="assign_upload.php" method="post" enctype="multipart/form-data" >
          <h4><center><b>Upload File</b></center></h4>
          <input type="file" name="myfile"> <br>
           <br><br><button class="but1" type="submit" name="save"><b>UPLOAD</b></button>
        </form>
    </div>
  </div></div>
 
        <?
    }}}
?>
</div>
</form>

</body>
</html>