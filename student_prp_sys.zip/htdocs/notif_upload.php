<?php 
session_start();
include("dbconfig.php");
if (isset($_POST['notify'])){
	$title = $_POST['title'];
	$content = $_POST['content'];
	$sql = "insert into notif(title,content,teacher_name) values('".$title."', '".$content."', '".$_SESSION['username']."') ";
	$query = mysqli_query($conn,$sql);
	echo "<script>alert('Success')</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="navbar.css">
	<title>Upload Notifications</title>
    <style>

 
* {
  box-sizing: border-box;
}


/* Style the counter cards */
.card {
    width:80%;
    margin-left:10%;
 padding-top:5%;
 padding-bottom:5%;
text-align: center;
  background-color: white;
  color:#2ebfac;
  border: solid 1.5px #888888;
}

.card:hover {
  color:#2ebfac;
  background-color: white;
  text-decoration: none;
  border:none;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.but2{
border-radius:8px;
background-color:#2ebfac;
color:white;
border: solid 2px #2ebfac;
padding: 3%;
font-size:20px;
cursor:pointer;
font-weight: bold;
}
.but2:hover{
    background-color:white;
    color:#2ebfac;
    border: solid 2px #2ebfac;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    
}
h2{
    color:black;
    
}
p{
    color:black;
    font-family: 'Anton', sans-serif;
    font-size: 18px;
}
.ab{
    width:200px;
}
.block{
    background-color:#2ebfac;
    padding-top:4%;
    padding-bottom:4%;
    color:white;
    font-size: 25px;
    font-weight: bold;
}
.block2{
    background-color:white;
    padding:3%;
    width:70%;
    margin-left:15%;
}
.active {
    color:#888888;
}
</style>  
</head>
<body>
<header>
  <ul>
  <li style=""><a class="icons" href="teacher_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
  <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOG OUT</a></li>
  <li style="float:right;"><a class="active" href="notif_upload.php">UPLOAD NOTIFICATIONS</a></li>
  <li style="float:right;"><a href="view_asgnsub.php">VIEW ASSIGNMENTS</a></li>
  <li style="float:right;"><a href="view_expsub.php">VIEW EXPERIMENTS</a></li>
  <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
  </ul>
</header>
<br><br><br><br><br>
<div class="block2">
<form method="POST" action="?">
<div class="card">
<div class="block">NOTIFICATION</div>
    <p><b>TITLE:</b></p>
	<input type="text" name="title" class="ab"><br><br>
    <p><b>CONTENT:</b></p>
    <input type="text" name="content" class="ab">
	<br><br><button type="submit" class="but2" name="notify">POST NOTIFICATION</button>
  
</div>
</form>
</div>
</body>
</html>

