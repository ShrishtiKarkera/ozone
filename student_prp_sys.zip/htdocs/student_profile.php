<?php
session_start();
include("dbconfig.php");
$username = $_SESSION['username'];
$password = $_SESSION['password'];
$sql = "select * from student where username = '".$username."'";
$query = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($query)) {
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="navbar.css">
  <style>
.card {
    float: left;
    margin-top: 15%;
    width: 50%;
 box-shadow: 0 4px 8px 0 rgba(255, 255, 255, 0.9);
  margin-left: 25%;
  background-color: cornsilk !important;
  border:2px solid black;
  border-radius: 30px;
  text-align: center;
  font-family: arial;
}
.title{
  font-size: 20px;
  color: #404040;
}

.button:hover {
  background-color: #303030;
}

.editbtn {
  border:none;
  margin:0px;
  display: inline-block;
  color: white;
  padding-top: 5px;
  background-color: black;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
  text-decoration: none;
  border-bottom-left-radius: 30px;
  border-bottom-right-radius: 30px;
}
.icons1{
    color:#888888;
    text-decoration: none;
    cursor:pointer;
}
.active {
    color:#888888;
}
</style>
</head>
<body>
  <header>
    <ul>
      <li style=""><a class="icons, active" href="student_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
      <li style=""><a href="IP_02.html" target="_blank">TIMETABLE</a></li>
      <li style=""><a href="mail.php">SEND MAIL</a></li>
      <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOGOUT</a></li>
      <li style="float:right;"><a href="view_marks.php">VIEW MARKS</a></li>
      <li style="float:right;"><a href="view_notif.php">NOTIFICATIONS</a></li>
      <li style="float:right;"><a href="upload.php">SUBMISSIONS</a></li>
      <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
      
    </ul>
  </header>
<div class="block1" style="background-color:#ffffe6 no-repeat center;-webkit-background-size:cover;
  background-size: cover;
  background-position: center;" id="home">
  <div>
  <br><br><br>
<div class="card" >

   <h3 style="font-size: 27px;"><?php echo $row['username'];?></b></h3>
  <p class="title"><?php echo $row['student_id'];$_SESSION['student_id'] = $row['student_id'];?></p>
  <p>INFORMATION TECHNOLOGY</p>
  <div style="margin: 24px 0; color:#404040;">
 
    <a class="icons1" href="https://twitter.com/login" target="_blank"><i class="fa fa-twitter"></i>  Twitter</a><br><br>
     <a class="icons1" href="https://en-gb.facebook.com/login/" target="_blank"><i class="fa fa-facebook">  Facebook</i></a> <br><br>
    <a class="icons1" href="https://www.linkedin.com/m/login/" target="_blank"><i class="fa fa-linkedin">  Linked In</i></a><br><br>
    <a class="icons1" href="https://www.quora.com" target="_blank"><i class="fa fa-quora"></i>  Quora</a> 
  </div>
  <a class="editbtn" href="editpp.html">Edit Profile</a>
</div>


</div>

<div>



  

  

 

  

 
</div>
<!-- main-part ends -->

</body>
</html> 
<? }?>