<?php

session_start();
$conn= mysqli_connect('sql211.epizy.com','epiz_24488534','kithsirhs');

mysqli_select_db($conn,'epiz_24488534_sprocs');

$user=$_POST['user'];
$password=$_POST['password'];

$s="SELECT * FROM teacher WHERE username == '$user' && password == '$password'";
$result=mysqli_query($conn,$s);
$num = mysqli_num_rows($result);
$row=mysqli_fetch_assoc($result);
$SESSION["username"] = $user;
$SESSION["password"] = $password;
if($num==1){
    header('location:teacher_profile.html');
}
else{
    header('location:teacher_login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <title>Sign in</title>
  <style>
  	html { 
  background: url(classroom.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
  	
    .main {
        
        width: 400px;
        height: 400px;
        margin: 7em auto;
        border-radius: 1.5em;
        box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
        background-color: rgba(0,0,0,0.7) !important;
    }
    
    .sign {
        padding-top: 40px;
        color: white;
        font-family: 'Ubuntu', sans-serif;
        font-weight: bold;
        font-size: 30px;
        text-shadow: 0 0 3px #FFC312, 0 0 5px #FFC312; 
    }
    
    .un {
    width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: #FFC312;
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
    
    form.form1 {
        padding-top: 40px;
    }
    
    .pass {
            width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: #FFC312;
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
    
   
    .un:focus, .pass:focus {
        border: 2.5px solid #D0D0D0 !important;
        
    }
    
    .submit {
      cursor: pointer;
        border-radius: 5em;
        color: #fff;
        background: linear-gradient(to right, #9C27B0, #E040FB);
        border: 0;
        padding-left: 40px;
        padding-right: 40px;
        padding-bottom: 10px;
        padding-top: 10px;
        font-family: 'Ubuntu', sans-serif;
        font-size: 13px;
        box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.04);
    }
        
    @media (max-width: 600px) {
        .main {
            border-radius: 0px;
        }

    </style>
</head>

<body>
	<center>
  <div class="main">
    <p class="sign" align="center">SIGN IN</p>
    <form class="form1" method="POST" autocomplete="off" action="?">
      <input class="un" type="text" name="user" align="center" placeholder="USERNAME">
      <input class="pass" type="password" name="password" align="center" placeholder="PASSWORD"><br><br>
      <input type="submit" class="submit" align="center">SIGN IN</input>
                
    </div>
     <center>
</body>

</html>

