<?php
session_start();
include("dbconfig.php");
$username = $_SESSION['username'];
$password = $_SESSION['password'];
$sql = "select * from teacher where username = '".$username."'";
$query = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html>
<head>
  <title>Teacher Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="navbar.css">
<style>
        
.block1 {
    width:100%;
  height: 500px;
}
        

.card {
    float: left;
    margin-top: 15%;
    width: 50%;
 box-shadow: 0 4px 8px 0 rgba(255, 255, 255, 0.9);
  margin-left: 25%;
  background-color: cornsilk !important;
  border:2px solid black;
  border-radius: 30px;
  text-align: center;
  font-family: arial;
}

.title{
  font-size: 20px;
  color: #404040;
}


.button:hover {
  background-color: #303030;
}


.editbtn {
  border:none;
  margin:0px;
  display: inline-block;
  color: white;
  padding-top: 5px;
  background-color: black;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
  text-decoration: none;
  border-bottom-left-radius: 30px;
  border-bottom-right-radius: 30px;
}
.icons1{
   color:#888888;
    text-decoration: none;
    cursor:pointer;
}
.active {
    color:#888888;
}
</style> 
</head>
<body>
<header>
  <ul>
  <li style=""><a class="icons, active" href="teacher_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
  <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOG OUT</a></li>
  <li style="float:right;"><a href="notif_upload.php">UPLOAD NOTIFICATIONS</a></li>
  <li style="float:right;"><a href="view_asgnsub.php">VIEW ASSIGNMENTS</a></li>
  <li style="float:right;"><a href="view_expsub.php">VIEW EXPERIMENTS</a></li>
  <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
  </ul>
</header>

<div class="block1" style="background-color:#ffffe6 no-repeat center;-webkit-background-size:cover;
  background-size: cover;
  background-position: center;" id="home">
    
    
  <div class="card">
  <h3 style="font-size: 27px;"><?php echo $row['username'];?> </h3>
  <p class="title"><?php echo $row['subject_id'];$_SESSION['subject_id'] = $row['subject_id'];$_SESSION['teacher_id'] = $row['teacher_id'];?></p>
  <p class="title">INFORMATION TECHNOLOGY</p>
  <div style="margin: 24px 0; color:#404040;">
    <a class="icons1" href="https://twitter.com/login" target="_blank"><i class="fa fa-twitter"></i>  Twitter</a><br><br>
    <a class="icons1" href="https://www.linkedin.com/m/login/" target="_blank"><i class="fa fa-linkedin">  Linked In</i></a><br><br>
    <a class="icons1" href="https://www.quora.com" target="_blank"><i class="fa fa-quora"></i>  Quora</a> 
  </div>
  <a class="editbtn" href="editpp.html">Edit Profile</a>
  </div>
  </div>

</body>
</html>
 
<? }?>