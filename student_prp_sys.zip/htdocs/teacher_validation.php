<?php
session_start();
include("dbconfig.php");
echo"in validation page";
if(isset($_POST['submit']))
	{
		echo"post submit";
		$username = $_POST['username'];
		$password = $_POST['password'];

		$lq = "SELECT * FROM teacher WHERE username='".$username."' AND password='".$password."'";
		$eql = mysqli_query($conn, $lq);
		$count = mysqli_num_rows($eql);  
		echo $count;    //to get the count of result query
		if($count ==1 )
		{
			// Session declaration :-
			//$_SESSION['loginstatus'] = 1;  //make login status 1
			//$_SESSION['email']= $email;	   //to make the login session accessable to multiple pages 
			echo "login successful";
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            echo $_SESSION['username'];
            echo $_SESSION['password'];
			header('Location:teacher_profile.php');	//to redirect it directly to userlogin page after checking email and pasword.
		}
		else
		{
			
			echo"login failed";
			header('Location:index.html');	
		}
	}

?>
