<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="navbar.css">
  <title>Student Upload</title>
 <style>


* {
  box-sizing: border-box;
}


/* Float four columns side by side */
.column {
  float: left;
  width: 33.3%;
  padding: 0 20px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  width:100%;
  padding-top:7%;
  padding-bottom:7%;
  text-align: center;
  background-color:#2ebfac;
  border: solid 1px #888888;
}

.card:hover {
 background-color:#2ebfac;
    text-decoration: none;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    border: none;
}

.button {background-color: white;

border-radius: 12px;
padding: 4% 3%;
border: solid 2px #888888;
width: 90%;
color: #888888;
font-family:"Trebuchet MS", Helvetica, sans-serif;
font-size:18px;
cursor: pointer;
}
.button:hover{
    background-color:white;
    color: #2ebfac;
    border: solid 2px #888888;

}
.container{
    background-color:#ffff;
    width:100%;
    left:0%;
    padding-top:8%;
    padding-bottom:8%;
}
.active {
    color:#888888;
}
 </style> 
</head>
<body>
<header>
    <ul>
     <li style=""><a class="icons" href="student_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
      <li style=""><a href="IP_02.html" target="_blank">TIMETABLE</a></li>
      <li style=""><a href="mail.php">SEND MAIL</a></li>
      <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOGOUT</a></li>
      <li style="float:right;"><a href="view_marks.php">VIEW MARKS</a></li>
      <li style="float:right;"><a href="view_notif.php">NOTIFICATIONS</a></li>
      <li style="float:right;"><a class="active" href="upload.php">SUBMISSIONS</a></li>
      <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
      
    </ul>
  </header>
  <br> <br> <br> <br> <br> <br> 
  <div class="container">
  <form method="POST" action="exp_form.php">
  <div class="row">
    <div class="column">
    <div class="card">
    <input type="submit" class="button" name="s_01" value="Internet Programming">
  </div>
</div>

<div class="column">
    <div class="card">
    <input type="submit" class="button" name="s_02" value="Microcontollers and Embedded Processors">
  </div>
</div>

<div class="column">
    <div class="card">
    <input type="submit" class="button" name="s_03" value="Cryptography and Network Security">
  </div>
</div>
</div>
<br>
<br>

<div class="row">
<div class="column">
    <div class="card">
    <input type="submit" class="button" name="s_04" value="Computer Graphics and Virtual Reality">
  </div>
</div>

<div class="column">
    <div class="card">
    <input type="submit" class="button" name="s_05" value="Advance Database Management Techniques">
  </div>
</div>

<div class="column">
    <div class="card">
    <input type="submit" class="button" name="s_06" value="Business Communication and Ethics">
  </div>
</div>
 
</div>
  </form>
</div>

</body>
</html>