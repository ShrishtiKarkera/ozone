
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="navbar.css">
<style>
.column {
  float: left;
  width: 50%;
  margin-left:25%;
}
.card {
  width:100%;
  padding-top:2%;
  padding-bottom:2%;
  text-align: center;
  font-size:25px;
  background-color:white;
  border: solid 3px #2ebfac;
  color:#888888;
}
.card:hover{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    
    border:none;
}
.but{
    border:solid 2px #888888;
    color:white;
    background-color:#888888;
    cursor:pointer;
}
.but:hover{
    border:solid 2px #2ebfac;
    color:#2ebfac;
    background-color:white;
    cursor:pointer;
}
.active {
    color:#888888;
}
</style>
<body>
<header>
  <ul>
  <li style=""><a class="icons" href="teacher_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
  <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOG OUT</a></li>
  <li style="float:right;"><a href="notif_upload.php">UPLOAD NOTIFICATIONS</a></li>
  <li style="float:right;"><a class="active" href="view_asgnsub.php">VIEW ASSIGNMENTS</a></li>
  <li style="float:right;"><a href="view_expsub.php">VIEW EXPERIMENTS</a></li>
  <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
  </ul>
</header>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php 
session_start();
include("dbconfig.php");
if (isset($_POST['save_marks'])){
    
	$marks = $_POST['marks'];
    
	$sql1 = "update assign_notes set marks = '".$marks."' where assign_name = '".$_SESSION['assign_name']."' and student_id = '".$_SESSION['student_id']."' and assign_id = '".$_SESSION['assign_id']."'";
	$query1 = mysqli_query($conn,$sql1);
	if(mysqli_num_rows($query1)){
        
	    echo "<script>alert('Success')</script>";
	}
}
?>

<?php 
session_start();
include("dbconfig.php");

	$sql = "select * from assign_notes where marks = 0 and subject_id = '".$_SESSION['subject_id']."'";
	$query = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_assoc($query)){?>
     <div class="column">
<div class="card">
      <form method="POST" action="?">
      
      <?php echo $row['assign_name'];?><br>
      <?php echo $row['assign_id'];$_SESSION['assign_id']=$row['assign_id'];?><br>
      <?php echo $row['student_id'];$_SESSION['student_id']=$row['student_id'];$_SESSION['assign_name']=$row['assign_name'];?><br>
    <?php $file = $row['student_id']."_".$row['assign_id'];
    echo '<a href="download.php?file='.urlencode($file).'">Download</a>';?>
      <input type='text' name='marks'>
      <button class="but" type='submit' name='save_marks'>ASSESS</button>
      </div></div>
      </form>
	<?php
}

?>
</body>
</html>

