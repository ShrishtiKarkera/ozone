<!DOCTYPE html>
<html>
<head>
  <title>View Marks</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="navbar.css">
  <style>
  * {
  box-sizing: border-box;
}
.active {
    color:#888888;
}
 .column {
  float: left;
  width: 33.3%;
  padding: 0 20px;
}
.card {
  padding-top:7%;
  padding-bottom:7%;
  text-align: center;
  background-color:white;
  font-size:25px;
  color:#888888;
  border: solid 3px #2ebfac;
}

.card:hover {
  color:#888888;
  background-color:white;
  text-decoration: none;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

</style>
</head>
<body>
<header>
    <ul>
      <li style=""><a class="icons" href="student_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
      <li style=""><a href="IP_02.html" target="_blank">TIMETABLE</a></li>
      <li style=""><a href="mail.php">SEND MAIL</a></li>
      <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOGOUT</a></li>
      <li style="float:right;"><a class="active" href="view_marks.php">VIEW MARKS</a></li>
      <li style="float:right;"><a href="view_notif.php">NOTIFICATIONS</a></li>
      <li style="float:right;"><a href="upload.php">SUBMISSIONS</a></li>
      <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
    </ul>
  </header>
<br><br><br><br><br><br><br><br><br>
<?php 
session_start();
include("dbconfig.php");
$sql = "select * from exp_notes where student_id='".$_SESSION['student_id']."' ";
$query = mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($query)){
    ?>
    <div class="column">
    <div class="card">
    <?php


      echo $row['exp_name'];?><br><?php
      echo $row['subject_id'];?><br><?php
      echo $row['marks'];
      ?>
      </div><br></div>
      <?php

}
      ?>
       

<?php 
session_start();
include("dbconfig.php");
$sql = "select * from assign_notes where student_id='".$_SESSION['student_id']."' ";
$query =mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($query)){
     ?>
    <div class="column">
    <div class="card">
    <?php

      echo $row['assign_name'];?><br><?php
      echo $row['subject_id'];?><br><?php
      echo $row['marks'];
      ?>
      </div><br></div>
      <?php
}
      ?> 
</body>
</html>    
