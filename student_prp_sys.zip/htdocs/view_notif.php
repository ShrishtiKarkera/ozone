<br><br><br><br><br><br>
<?php
session_start();
include("dbconfig.php");
$sql = "select * from notif";
$query = mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($query)){?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="navbar.css">	
  <style>
* {
  box-sizing: border-box;
}


.column {
  float: left;
  width: 33.3%;
  padding: 0 20px;
}



/* Style the counter cards */
.card {
  //box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color:white;
  color:#2ebfac;
  border: solid 3px #2ebfac;
}

.card:hover {
  color:#2ebfac;
  background-color:white;
  text-decoration: none;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

h2{
    color:#888888;
}
.active {
    color:#888888;
}
</style>  
</head>
<body>
<header>
    <ul>
      <li style=""><a class="icons" href="student_profile.php"><i class="fa fa-bars"></i> HOME</a></li>
      <li style=""><a href="IP_02.html" target="_blank">TIMETABLE</a></li>
      <li style=""><a href="mail.php">SEND MAIL</a></li>
      <li style="float:right;"><a class="icons" href="logout.php"><i class="fa fa-sign-out"></i> LOGOUT</a></li>
      <li style="float:right;"><a href="view_marks.php">VIEW MARKS</a></li>
      <li style="float:right;"><a class="active" href="view_notif.php">NOTIFICATIONS</a></li>
      <li style="float:right;"><a href="upload.php">SUBMISSIONS</a></li>
      <li style="float:right;"><a href="doubt.php">DOUBT BOX</a></li>
    </ul>
</header>

<div class="column">
<div class="card">
      <label><h2><?php echo $row['title'];?></h2></label>
      <label><h3><?php echo $row['content'];?></h3></label>
      <label><h3>Uploaded by ~Prof. <?php echo $row['teacher_name'];?></h3></label>
      </div><br></div> 
</body>
</html>

<?php 
}
?>

